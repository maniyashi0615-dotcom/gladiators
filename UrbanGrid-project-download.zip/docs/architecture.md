# UrbanGrid architecture notes

The React app is a public/client presentation layer. Auth, validation, duplicate decisions, private file upload, routing decisions, and officer authorization are enforced by Postgres and Supabase Edge Functions.

`submit-report` performs deterministic geographic candidate discovery before optional model inference. AI output only contributes to an explainable match decision. A Postgres transaction repeats the distance and category checks while holding a transaction-scoped advisory lock, then creates a ticket or attaches a supporting report and notification atomically. Concurrent reports are therefore aggregated without allowing the AI to set the distance limit.

Ward routing in this MVP chooses the nearest seeded ward center within the Chennai demo bounds. Unmapped locations are rejected. Replace the sample mapping with validated ward polygons or an official municipal mapping source before multi-city deployment.
