# API and data flows

All sensitive writes run in Supabase Edge Functions using the requester's verified Supabase Auth JWT. The service-role credential is function-only.

## `submit-report` (JWT required)

POST JSON: `category`, `description`, `latitude`, `longitude`, `severity`, `image_name`, `image_type`, `image_base64`.

Checks citizen role, image MIME/size, text and coordinates; routes the configured ward; stores evidence privately; fetches active 50m candidates; compares same-category images/descriptions server-side; calls `commit_civic_report`; returns the public ticket ID, duplicate flag, count, priority and explainable match signals.

## `warden-login` (no JWT; officer/password required)

POST JSON: `officer_id`, `password`. Looks up a pre-authorized active Warden/Admin account by officer ID and authenticates the password with Supabase Auth. Invalid/inactive credentials receive a generic response. No public account creation path exists.

## `update-issue-status` (JWT required)

POST JSON: `issue_id`, `status`, optional `note`. Confirms Warden/Admin role and ward assignment, then commits issue update and status history in a database transaction.

## `get-issue-evidence` (JWT required)

POST JSON: `issue_id`. Confirms ward assignment and returns short-lived signed image URLs for the issue and supporting reports.

## Public ticket

The database RPC `public_ticket(ticket_id)` returns only safe ticket fields and the status timeline. It excludes exact coordinates, image paths and citizen data.
