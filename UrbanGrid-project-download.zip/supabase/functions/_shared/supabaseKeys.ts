function defaultKeyFromJson(value: string | undefined): string | undefined {
  if (!value) return undefined;
  try {
    const keys = JSON.parse(value);
    return keys.default || Object.values(keys)[0] as string | undefined;
  } catch {
    return undefined;
  }
}

// Supabase injects the newer key collections by default. Fall back to legacy
// runtime variables so existing projects remain compatible during migration.
export function getSecretKey(): string {
  const key = defaultKeyFromJson(Deno.env.get('SUPABASE_SECRET_KEYS')) || Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
  if (!key) throw new Error('Supabase server secret key is unavailable in this Edge Function runtime.');
  return key;
}

export function getPublishableKey(): string {
  const key = defaultKeyFromJson(Deno.env.get('SUPABASE_PUBLISHABLE_KEYS')) || Deno.env.get('SUPABASE_ANON_KEY');
  if (!key) throw new Error('Supabase publishable key is unavailable in this Edge Function runtime.');
  return key;
}
