import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { getSecretKey } from '../_shared/supabaseKeys.ts';

const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const categories = new Set(['Pothole','Garbage','Water leak','Road damage','Streetlight','Other']);
const mimeExt: Record<string,string> = {'image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
const json = (body: unknown, status=200) => new Response(JSON.stringify(body), { status, headers: { ...cors, 'Content-Type':'application/json' } });
const tokens = (s: string) => new Set(s.toLowerCase().replace(/[^a-z0-9 ]/g,' ').split(/\s+/).filter(x=>x.length>2));
function textSimilarity(a: string,b: string) { const aa=tokens(a),bb=tokens(b); if(!aa.size||!bb.size)return 0; let common=0; for(const t of aa)if(bb.has(t))common++; return common/(aa.size+bb.size-common); }

function toBase64(bytes: Uint8Array) { let binary=''; for(let i=0;i<bytes.length;i+=0x8000) binary+=String.fromCharCode(...bytes.subarray(i,i+0x8000)); return btoa(binary); }
async function aiMatch(newImage: string, oldImage: string, newMime: string, oldMime: string, category: string, description: string, oldDescription: string) {
  const key=Deno.env.get('OPENAI_API_KEY'); if(!key) return null;
  const model=Deno.env.get('OPENAI_MODEL')||'gpt-4o-mini';
  const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model,temperature:0,response_format:{type:'json_object'},messages:[{role:'system',content:'You help municipal staff decide whether two civic reports show the same physical issue. Compare visible scene details, fixed landmarks, damage shape/context and descriptions. Be conservative: same category and proximity alone do not prove a duplicate. Return JSON only: {"same_issue":boolean,"image_similarity":"high|medium|low","description_similarity":"high|medium|low","category_match":boolean,"confidence":number,"reason":"short explanation"}.'},{role:'user',content:[{type:'text',text:`New report category: ${category}\nNew description: ${description}\nExisting report category: ${category}\nExisting description: ${oldDescription}\nCompare whether these are likely the same physical civic issue.`},{type:'image_url',image_url:{url:`data:${newMime};base64,${newImage}`,detail:'low'}},{type:'image_url',image_url:{url:`data:${oldMime};base64,${oldImage}`,detail:'low'}}]}]})});
  if(!response.ok) throw new Error(`AI service returned ${response.status}`); const data=await response.json(); return JSON.parse(data.choices?.[0]?.message?.content||'{}');
}

Deno.serve(async req=>{
  if(req.method==='OPTIONS')return new Response('ok',{headers:cors}); if(req.method!=='POST')return json({error:'Method not allowed.'},405);
  try {
    const auth=req.headers.get('Authorization'); if(!auth?.startsWith('Bearer '))return json({error:'Sign in to submit a report.'},401);
    const base=Deno.env.get('SUPABASE_URL')!, service=getSecretKey();
    const db=createClient(base,service,{auth:{persistSession:false}}); const {data:{user},error:userError}=await db.auth.getUser(auth.slice(7));
    if(userError||!user)return json({error:'Your session expired. Sign in again.'},401);
    const {data:profile}=await db.from('profiles').select('role').eq('id',user.id).single(); if(profile?.role!=='citizen')return json({error:'Only citizen accounts can submit reports.'},403);
    const body=await req.json(); const category=String(body.category||''),description=String(body.description||'').trim(),lat=Number(body.latitude),lon=Number(body.longitude),severity=String(body.severity||'MEDIUM').toUpperCase();
    const mime=String(body.image_type||''); const raw=String(body.image_base64||'');
    if(!categories.has(category))return json({error:'Choose a valid civic issue category.'},400);
    if(description.length<8||description.length>700)return json({error:'Description must be between 8 and 700 characters.'},400);
    if(!Number.isFinite(lat)||lat < -90||lat>90||!Number.isFinite(lon)||lon < -180||lon>180)return json({error:'Enter valid latitude and longitude coordinates.'},400);
    if(!mimeExt[mime]||!raw)return json({error:'Upload a JPG, PNG or WEBP photo.'},400);
    if(raw.length>11_200_000)return json({error:'Photo must be smaller than 8 MB.'},400);
    let imageBytes: Uint8Array; try { imageBytes=Uint8Array.from(atob(raw),c=>c.charCodeAt(0)); } catch { return json({error:'The uploaded image could not be read. Choose a valid photo.'},400); } if(imageBytes.byteLength>8*1024*1024)return json({error:'Photo must be smaller than 8 MB.'},400);
    if(!['LOW','MEDIUM','HIGH','CRITICAL'].includes(severity))return json({error:'Choose a valid severity.'},400);
    const {data:wardId,error:wardError}=await db.rpc('route_ward',{lat,lon}); if(wardError)throw wardError; if(!wardId)return json({error:'Ward routing is not configured for this location yet. UrbanGrid’s demo wards currently cover Chennai.'},422);
    const path=`${user.id}/${crypto.randomUUID()}.${mimeExt[mime]}`;
    const {error:uploadError}=await db.storage.from('civic-evidence').upload(path,imageBytes,{contentType:mime,upsert:false}); if(uploadError)throw new Error(`Could not store the evidence photo: ${uploadError.message}`);
    const {data:candidates,error:candidateError}=await db.rpc('nearby_active_issues',{lat,lon,radius_m:50}); if(candidateError){await db.storage.from('civic-evidence').remove([path]);throw candidateError;}
    let best:any=null,aiAvailable=Boolean(Deno.env.get('OPENAI_API_KEY'));
    for(const candidate of candidates||[]) {
      if(candidate.category.toLowerCase()!==category.toLowerCase())continue;
      const {data:signed}=await db.storage.from('civic-evidence').createSignedUrl(candidate.image_path,90);
      let match:any=null;
      try { if(signed?.signedUrl) { const oldRes=await fetch(signed.signedUrl); if(oldRes.ok){const oldBytes=new Uint8Array(await oldRes.arrayBuffer()); const oldImage=toBase64(oldBytes); const oldMime=oldRes.headers.get('content-type')||mime; match=await aiMatch(toBase64(imageBytes),oldImage,mime,oldMime,category,description,candidate.description); } } }
      catch { aiAvailable=false; }
      const lexical=textSimilarity(description,candidate.description);
      const image=match?.image_similarity||'unknown'; const desc=match?.description_similarity||(lexical>=0.38?'medium':lexical>=0.18?'low':'low');
      const combined=match?.confidence ?? Math.min(0.70,lexical*0.95 + (image==='high'?0.16:image==='medium'?0.08:0));
      const accepted=match ? match.same_issue===true && Number(match.confidence)>=0.76 && (image==='high'||desc==='high') : lexical>=0.48;
      const evidence={distance_m:Math.round(candidate.distance_m),image_similarity:image,description_similarity:desc,category_match:true,confidence:Number(combined.toFixed(2)),reason:match?.reason||'Nearby issue type and description match.'};
      if(accepted&&(!best||combined>best.score)){best={candidate,evidence,score:combined};}
    }
    const consideredCandidate=(candidates||[]).find((c:any)=>c.category.toLowerCase()===category.toLowerCase());
    const {data:result,error:commitError}=await db.rpc('commit_civic_report',{p_candidate_id:best?.candidate.id||consideredCandidate?.id||null,p_citizen_id:user.id,p_category:category,p_description:description,p_lat:lat,p_lon:lon,p_image_path:path,p_severity:severity,p_match_score:best?.score||0,p_ai_duplicate:best!==null});
    if(commitError){await db.storage.from('civic-evidence').remove([path]);if(commitError.message?.includes('already reported'))return json({error:'You have already added a report to this ticket.'},409);throw commitError;}
    return json({...result,match:result.duplicate?(best?.evidence||{distance_m:result.distance_m,image_similarity:'unavailable',description_similarity:'similar',category_match:true,confidence:0.5,reason:'Matched through proximity and deterministic description checks.'}):null,ai_available:aiAvailable});
  } catch(error) { console.error('submit-report failed',error); return json({error:error instanceof Error?error.message:'The report could not be saved. Please try again.'},500); }
});
