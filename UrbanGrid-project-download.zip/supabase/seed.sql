-- Optional demo geography only. These rows also ship idempotently in the migration.
insert into public.wards(id,ward_number,name,center_latitude,center_longitude) values
(18,18,'Mylapore',13.0335,80.2690),
(27,27,'Kodambakkam',13.0520,80.2210),
(42,42,'T. Nagar',13.0418,80.2341)
on conflict(id) do nothing;

-- No users, tickets, passwords, or fake reports are seeded. Use real test accounts
-- and submit reports through the application so the demo exercises live persistence.
