create extension if not exists pgcrypto;
create extension if not exists pg_trgm;
create sequence if not exists public.ticket_number_seq start 1;
create sequence if not exists public.user_code_seq start 1;

create table public.wards (
  id integer primary key,
  ward_number integer not null unique,
  name text not null,
  center_latitude double precision not null,
  center_longitude double precision not null,
  assigned_warden_id uuid
);
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  user_code text unique,
  full_name text not null default 'Citizen',
  role text not null default 'citizen' check(role in ('citizen','warden','admin')),
  officer_id text unique,
  ward_id integer references public.wards(id),
  created_at timestamptz not null default now(),
  check ((role='citizen' and officer_id is null and ward_id is null) or (role in ('warden','admin') and officer_id is not null and ward_id is not null))
);
alter table public.wards add constraint wards_assigned_warden_fk foreign key (assigned_warden_id) references public.profiles(id) on delete set null;
create table public.issues (
  id uuid primary key default gen_random_uuid(),
  ticket_id text not null unique,
  category text not null,
  description text not null,
  latitude double precision not null check(latitude between -90 and 90),
  longitude double precision not null check(longitude between -180 and 180),
  image_path text,
  priority text not null default 'MEDIUM' check(priority in ('LOW','MEDIUM','HIGH','CRITICAL')),
  report_count integer not null default 1 check(report_count > 0),
  status text not null default 'PENDING' check(status in ('PENDING','ASSIGNED','IN_PROGRESS','RESOLVED')),
  ward_id integer not null references public.wards(id),
  assigned_warden_id uuid references public.profiles(id),
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.supporting_reports (
  id uuid primary key default gen_random_uuid(),
  issue_id uuid not null references public.issues(id) on delete cascade,
  citizen_id uuid not null references public.profiles(id),
  description text not null,
  image_path text not null,
  latitude double precision not null,
  longitude double precision not null,
  match_score numeric(5,4),
  created_at timestamptz not null default now()
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  warden_id uuid not null references public.profiles(id),
  issue_id uuid not null references public.issues(id) on delete cascade,
  title text not null,
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.status_history (
  id uuid primary key default gen_random_uuid(),
  issue_id uuid not null references public.issues(id) on delete cascade,
  status text not null check(status in ('PENDING','ASSIGNED','IN_PROGRESS','RESOLVED')),
  changed_by uuid references public.profiles(id),
  note text,
  created_at timestamptz not null default now()
);
create index issues_location_idx on public.issues(latitude,longitude) where status <> 'RESOLVED';
create index issues_ward_status_idx on public.issues(ward_id,status,priority);
create index reports_citizen_idx on public.supporting_reports(citizen_id,created_at desc);
create index reports_issue_idx on public.supporting_reports(issue_id,created_at);
create unique index reports_one_per_citizen_issue on public.supporting_reports(issue_id,citizen_id);
create index notifications_warden_idx on public.notifications(warden_id,read,created_at desc);
create index history_issue_idx on public.status_history(issue_id,created_at);

create or replace function public.make_user_code() returns text language sql volatile as $$
  select 'U-' || lpad(nextval('public.user_code_seq')::text,5,'0')
$$;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,user_code,full_name,role)
  values(new.id,public.make_user_code(),coalesce(nullif(new.raw_user_meta_data->>'full_name',''),'Citizen'),'citizen');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();

create or replace function public.distance_m(lat1 double precision,lon1 double precision,lat2 double precision,lon2 double precision)
returns double precision language sql immutable parallel safe as $$
select 6371000 * 2 * asin(sqrt(least(1.0,
  power(sin(radians(lat2-lat1)/2),2) + cos(radians(lat1))*cos(radians(lat2))*power(sin(radians(lon2-lon1)/2),2))))
$$;
create or replace function public.route_ward(lat double precision,lon double precision) returns integer
language sql stable security definer set search_path=public as $$
  select case when lat between 12.85 and 13.25 and lon between 80.10 and 80.35
    then (select id from public.wards order by public.distance_m(lat,lon,center_latitude,center_longitude) limit 1)
    else null end
$$;
create or replace function public.nearby_active_issues(lat double precision,lon double precision,radius_m double precision default 50)
returns table(id uuid,ticket_id text,category text,description text,image_path text,latitude double precision,longitude double precision,report_count integer,priority text,distance_m double precision)
language sql stable security definer set search_path=public as $$
select i.id,i.ticket_id,i.category,i.description,i.image_path,i.latitude,i.longitude,i.report_count,i.priority,
       public.distance_m(lat,lon,i.latitude,i.longitude)
from public.issues i where i.status <> 'RESOLVED'
  and abs(i.latitude-lat) < radius_m/110000.0
  and abs(i.longitude-lon) < radius_m/(111000.0*greatest(cos(radians(lat)),0.1))
  and public.distance_m(lat,lon,i.latitude,i.longitude) <= radius_m
order by 10 asc limit 10
$$;

-- One transaction and lock protect report aggregation from concurrent submissions.
create or replace function public.commit_civic_report(
  p_candidate_id uuid,p_citizen_id uuid,p_category text,p_description text,p_lat double precision,p_lon double precision,
  p_image_path text,p_severity text,p_match_score numeric,p_ai_duplicate boolean
) returns jsonb language plpgsql security definer set search_path=public as $$
declare target public.issues%rowtype; w integer; officer uuid; d double precision; duplicate boolean := false; new_ticket text; next_priority text; n integer;
begin
  perform pg_advisory_xact_lock(832771);
  w := public.route_ward(p_lat,p_lon);
  if p_candidate_id is not null then
    select * into target from public.issues where id=p_candidate_id and status <> 'RESOLVED' for update;
    if found then
      d:=public.distance_m(p_lat,p_lon,target.latitude,target.longitude);
      if d <= 50 and lower(target.category)=lower(p_category) and p_ai_duplicate then duplicate:=true; end if;
    end if;
  end if;
  -- Recheck after taking the lock so two first reports cannot both create a ticket.
  if not duplicate and p_candidate_id is null then
    select i.* into target from public.issues i where i.status <> 'RESOLVED'
      and lower(i.category)=lower(p_category)
      and public.distance_m(p_lat,p_lon,i.latitude,i.longitude)<=50
      and similarity(i.description,p_description)>=0.30
    order by public.distance_m(p_lat,p_lon,i.latitude,i.longitude) limit 1 for update;
    if found then duplicate:=true; d:=public.distance_m(p_lat,p_lon,target.latitude,target.longitude); end if;
  end if;
  if duplicate then
    if exists(select 1 from public.supporting_reports r where r.issue_id=target.id and r.citizen_id=p_citizen_id) then
      raise exception using errcode='23505',message='You have already reported this ticket.';
    end if;
    n:=target.report_count+1;
    next_priority:=case when p_severity='CRITICAL' then 'CRITICAL'
                        when greatest(n,0)>=5 or p_severity='HIGH' then 'HIGH'
                        when n>=2 or p_severity='MEDIUM' then 'MEDIUM' else 'LOW' end;
    update public.issues set report_count=n,priority=case
      when next_priority='CRITICAL' or priority='CRITICAL' then 'CRITICAL'
      when next_priority='HIGH' or priority='HIGH' then 'HIGH'
      when next_priority='MEDIUM' or priority='MEDIUM' then 'MEDIUM'
      else 'LOW' end,updated_at=now() where id=target.id returning * into target;
  else
    new_ticket:='UG-'||lpad(nextval('public.ticket_number_seq')::text,4,'0');
    next_priority:=case when p_severity='CRITICAL' then 'CRITICAL' when p_severity='HIGH' then 'HIGH' when p_severity='LOW' then 'LOW' else 'MEDIUM' end;
    insert into public.issues(ticket_id,category,description,latitude,longitude,image_path,priority,ward_id,assigned_warden_id,created_by)
      select new_ticket,p_category,p_description,p_lat,p_lon,p_image_path,next_priority,w,assigned_warden_id,p_citizen_id from public.wards where id=w
      returning * into target;
    insert into public.status_history(issue_id,status,changed_by,note) values(target.id,'PENDING',p_citizen_id,'Report received and routed to the responsible ward.');
  end if;
  insert into public.supporting_reports(issue_id,citizen_id,description,image_path,latitude,longitude,match_score)
    values(target.id,p_citizen_id,p_description,p_image_path,p_lat,p_lon,p_match_score);
  if target.assigned_warden_id is not null then
    insert into public.notifications(warden_id,issue_id,title,message)
    values(target.assigned_warden_id,target.id,case when duplicate then 'More neighbors reported this issue' else 'New issue in your ward' end,
      target.ticket_id||' · '||target.category||' · '||target.report_count||' report(s) · '||target.priority||' priority');
  end if;
  return jsonb_build_object('issue_id',target.id,'ticket_id',target.ticket_id,'duplicate',duplicate,'report_count',target.report_count,
    'priority',target.priority,'status',target.status,'ward_id',target.ward_id,'distance_m',case when duplicate then d else null end,
    'ai_assisted',coalesce(p_ai_duplicate,false));
end $$;

create or replace function public.public_ticket(p_ticket_id text) returns jsonb language sql stable security definer set search_path=public as $$
select jsonb_build_object('id',i.id,'ticket_id',i.ticket_id,'category',i.category,'priority',i.priority,
  'report_count',i.report_count,'status',i.status,'ward_id',i.ward_id,'created_at',i.created_at,'updated_at',i.updated_at,
  'ward_name',w.name,'history',coalesce((select jsonb_agg(jsonb_build_object('status',h.status,'note',h.note,'created_at',h.created_at) order by h.created_at)
   from public.status_history h where h.issue_id=i.id),'[]'::jsonb))
from public.issues i left join public.wards w on w.id=i.ward_id where upper(i.ticket_id)=upper(trim(p_ticket_id)) limit 1
$$;
create or replace function public.public_recent_tickets() returns table(ticket_id text,category text,ward_id integer,status text,report_count integer,updated_at timestamptz)
language sql stable security definer set search_path=public as $$
  select i.ticket_id,i.category,i.ward_id,i.status,i.report_count,i.updated_at
  from public.issues i order by i.updated_at desc limit 3
$$;
create or replace function public.can_view_issue(p_issue_id uuid) returns boolean language sql stable security definer set search_path=public as $$
select exists(select 1 from public.supporting_reports r where r.issue_id=p_issue_id and r.citizen_id=auth.uid())
 or exists(select 1 from public.issues i join public.profiles p on p.id=auth.uid() where i.id=p_issue_id and p.role in ('warden','admin') and (p.role='admin' or p.ward_id=i.ward_id))
$$;
create or replace function public.can_view_support_report(p_issue_id uuid,p_citizen_id uuid) returns boolean language sql stable security definer set search_path=public as $$
select p_citizen_id=auth.uid() or exists(select 1 from public.issues i join public.profiles p on p.id=auth.uid()
 where i.id=p_issue_id and p.role in ('warden','admin') and (p.role='admin' or p.ward_id=i.ward_id))
$$;
create or replace function public.commit_issue_status(p_issue_id uuid,p_status text,p_user_id uuid,p_note text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare current_issue public.issues%rowtype; ord text[]:=array['PENDING','ASSIGNED','IN_PROGRESS','RESOLVED'];
begin
  select * into current_issue from public.issues where id=p_issue_id for update;
  if not found then raise exception 'Issue not found'; end if;
  if p_status <> all(ord) then raise exception 'Invalid status'; end if;
  if array_position(ord,p_status)<array_position(ord,current_issue.status) then raise exception 'Issue status cannot move backwards'; end if;
  update public.issues set status=p_status,updated_at=now() where id=p_issue_id;
  insert into public.status_history(issue_id,status,changed_by,note) values(p_issue_id,p_status,p_user_id,coalesce(p_note,'Status updated to '||lower(replace(p_status,'_',' '))||'.'));
  return jsonb_build_object('ok',true,'ticket_id',current_issue.ticket_id,'status',p_status);
end $$;

alter table public.wards enable row level security;
alter table public.profiles enable row level security;
alter table public.issues enable row level security;
alter table public.supporting_reports enable row level security;
alter table public.notifications enable row level security;
alter table public.status_history enable row level security;
create policy "wards visible" on public.wards for select using(true);
create policy "profile self" on public.profiles for select using(id=auth.uid());
create policy "citizen and assigned ward issue access" on public.issues for select to authenticated using(public.can_view_issue(id));
create policy "support own or ward staff" on public.supporting_reports for select to authenticated using(public.can_view_support_report(issue_id,citizen_id));
create policy "notifications own" on public.notifications for select using(warden_id=auth.uid());
create policy "notifications mark own read" on public.notifications for update using(warden_id=auth.uid()) with check(warden_id=auth.uid());
revoke update on public.notifications from authenticated;
grant update(read) on public.notifications to authenticated;
create policy "status visible to ticket viewers" on public.status_history for select to authenticated using(public.can_view_issue(issue_id));
grant execute on function public.public_ticket(text) to anon,authenticated;
grant execute on function public.public_recent_tickets() to anon,authenticated;
grant execute on function public.nearby_active_issues(double precision,double precision,double precision) to service_role;
grant execute on function public.commit_civic_report(uuid,uuid,text,text,double precision,double precision,text,text,numeric,boolean) to service_role;
grant execute on function public.route_ward(double precision,double precision) to service_role;
grant execute on function public.commit_issue_status(uuid,text,uuid,text) to service_role;
grant execute on function public.can_view_issue(uuid) to authenticated;
grant execute on function public.can_view_support_report(uuid,uuid) to authenticated;
revoke all on function public.make_user_code() from public,anon,authenticated;
revoke all on function public.handle_new_user() from public,anon,authenticated;
revoke all on function public.distance_m(double precision,double precision,double precision,double precision) from public,anon,authenticated;
revoke all on function public.nearby_active_issues(double precision,double precision,double precision) from public,anon,authenticated;
revoke all on function public.commit_civic_report(uuid,uuid,text,text,double precision,double precision,text,text,numeric,boolean) from public,anon,authenticated;
revoke all on function public.route_ward(double precision,double precision) from public,anon,authenticated;
revoke all on function public.commit_issue_status(uuid,text,uuid,text) from public,anon,authenticated;
revoke all on function public.can_view_issue(uuid) from public,anon;
revoke all on function public.can_view_support_report(uuid,uuid) from public,anon;

insert into public.wards(id,ward_number,name,center_latitude,center_longitude) values
(18,18,'Mylapore',13.0335,80.2690),(27,27,'Kodambakkam',13.0520,80.2210),(42,42,'T. Nagar',13.0418,80.2341)
on conflict(id) do nothing;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('civic-evidence','civic-evidence',false,8388608,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=false,file_size_limit=8388608;
create policy "citizens upload their own evidence" on storage.objects for insert to authenticated with check(bucket_id='civic-evidence' and (storage.foldername(name))[1]=auth.uid()::text);
create policy "ward staff read evidence" on storage.objects for select to authenticated using(bucket_id='civic-evidence' and (storage.foldername(name))[1]=auth.uid()::text);
